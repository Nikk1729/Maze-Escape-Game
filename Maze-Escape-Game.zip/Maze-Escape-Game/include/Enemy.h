#ifndef ENEMY_H
#define ENEMY_H

#include "Entity.h"

class Enemy : public Entity {
public:
    explicit Enemy(Position start);
    char symbol() const override;
};

#endif
