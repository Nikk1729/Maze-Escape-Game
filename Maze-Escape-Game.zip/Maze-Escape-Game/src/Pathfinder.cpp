#include "Pathfinder.h"

#include <queue>
#include <vector>

namespace {
const Position kDirections[] = {
    {-1, 0},
    {1, 0},
    {0, -1},
    {0, 1},
};
}

std::optional<Position> Pathfinder::nextStep(
    const Maze& maze,
    Position start,
    Position goal
) {
    if (start == goal) {
        return start;
    }

    std::vector<std::vector<bool>> visited(
        maze.rows(),
        std::vector<bool>(maze.cols(), false)
    );
    std::vector<std::vector<Position>> parent(
        maze.rows(),
        std::vector<Position>(maze.cols(), Position{-1, -1})
    );

    std::queue<Position> frontier;
    frontier.push(start);
    visited[start.row][start.col] = true;

    while (!frontier.empty()) {
        Position current = frontier.front();
        frontier.pop();

        for (Position direction : kDirections) {
            Position next{current.row + direction.row, current.col + direction.col};
            if (!maze.isWalkable(next) || visited[next.row][next.col]) {
                continue;
            }

            visited[next.row][next.col] = true;
            parent[next.row][next.col] = current;

            if (next == goal) {
                Position step = next;
                while (parent[step.row][step.col] != start) {
                    step = parent[step.row][step.col];
                }
                return step;
            }

            frontier.push(next);
        }
    }

    return std::nullopt;
}
