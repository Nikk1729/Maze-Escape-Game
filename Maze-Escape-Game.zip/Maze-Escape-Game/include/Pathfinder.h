#ifndef PATHFINDER_H
#define PATHFINDER_H

#include <optional>

#include "Maze.h"
#include "Position.h"

class Pathfinder {
public:
    static std::optional<Position> nextStep(
        const Maze& maze,
        Position start,
        Position goal
    );
};

#endif
