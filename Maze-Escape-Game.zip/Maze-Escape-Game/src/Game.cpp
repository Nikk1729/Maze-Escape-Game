#include "Game.h"

#include <cctype>
#include <iostream>
#include <stdexcept>

#include "Pathfinder.h"

namespace {
Position deltaForInput(char input) {
    switch (input) {
        case 'w':
            return {-1, 0};
        case 's':
            return {1, 0};
        case 'a':
            return {0, -1};
        case 'd':
            return {0, 1};
        default:
            return {0, 0};
    }
}
}

Game::Game(const GameOptions& options)
    : maze_(options.levelPath), player_(maze_.playerStart()), options_(options) {
    for (const Position& start : maze_.enemyStarts()) {
        enemies_.emplace_back(start);
    }

    message_ = "Collect every token before escaping through the exit.";
}

int Game::run() {
    while (running_) {
        render();

        char input = nextInput();
        if (!handleInput(input)) {
            continue;
        }

        if (victoryReached()) {
            player_.addScore(50);
            playerWon_ = true;
            message_ = "You cleared the maze and escaped.";
            break;
        }

        moveEnemies();
        if (enemiesCaughtPlayer()) {
            playerLost_ = true;
            message_ = "An enemy caught you. Game over.";
            break;
        }

        if (player_.moves() >= options_.turnLimit) {
            playerLost_ = true;
            message_ = "Turn limit reached before escaping.";
            break;
        }
    }

    render();
    return playerWon_ ? 0 : 1;
}

void Game::render() const {
    if (options_.clearScreen) {
        clearTerminal();
    }

    std::vector<Position> enemyPositions;
    enemyPositions.reserve(enemies_.size());
    for (const Enemy& enemy : enemies_) {
        enemyPositions.push_back(enemy.position());
    }

    const std::vector<std::string> frame = maze_.render(player_.position(), enemyPositions);

    std::cout << "Maze Escape Game\n";
    std::cout << "Score: " << player_.score()
              << " | Collected: " << player_.collectedItems() << "/" << maze_.totalCollectibles()
              << " | Moves: " << player_.moves() << "/" << options_.turnLimit << "\n";
    std::cout << "Commands: w/a/s/d to move, q to quit\n";
    std::cout << message_ << "\n\n";

    for (const std::string& row : frame) {
        std::cout << row << "\n";
    }
    std::cout << "\n";
}

bool Game::handleInput(char input) {
    input = static_cast<char>(std::tolower(static_cast<unsigned char>(input)));

    if (input == 'q') {
        running_ = false;
        message_ = "You quit the game.";
        return false;
    }

    if (input != 'w' && input != 'a' && input != 's' && input != 'd') {
        message_ = "Invalid input. Use w, a, s, d, or q.";
        return false;
    }

    return tryMovePlayer(deltaForInput(input));
}

bool Game::tryMovePlayer(Position delta) {
    Position next{
        player_.position().row + delta.row,
        player_.position().col + delta.col,
    };

    if (!maze_.isWalkable(next)) {
        message_ = "That path is blocked by a wall.";
        return false;
    }

    player_.setPosition(next);
    player_.recordMove();
    message_ = "You moved deeper into the maze.";

    if (maze_.collectCollectible(next)) {
        player_.collectItem();
        player_.addScore(10);
        message_ = "Collectible secured. Keep moving.";
    }

    if (maze_.isExit(next) && !victoryReached()) {
        message_ = "The exit is locked until every collectible is secured.";
    }

    return true;
}

void Game::moveEnemies() {
    for (Enemy& enemy : enemies_) {
        const std::optional<Position> next =
            Pathfinder::nextStep(maze_, enemy.position(), player_.position());
        if (next.has_value()) {
            enemy.setPosition(*next);
        }
    }
}

bool Game::enemiesCaughtPlayer() const {
    for (const Enemy& enemy : enemies_) {
        if (enemy.position() == player_.position()) {
            return true;
        }
    }
    return false;
}

bool Game::victoryReached() const {
    return player_.position() == maze_.exitPosition() &&
           player_.collectedItems() == maze_.totalCollectibles();
}

char Game::nextInput() {
    if (replayIndex_ < options_.replayMoves.size()) {
        const char next = options_.replayMoves[replayIndex_++];
        std::cout << "Replay move: " << next << "\n";
        return next;
    }

    std::cout << "Enter move: ";
    std::string line;
    if (!std::getline(std::cin, line)) {
        return 'q';
    }
    if (line.empty()) {
        return '\0';
    }
    return line.front();
}

void Game::clearTerminal() const {
    std::cout << "\033[2J\033[H";
}
