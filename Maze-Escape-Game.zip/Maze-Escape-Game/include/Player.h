#ifndef PLAYER_H
#define PLAYER_H

#include "Entity.h"

class Player : public Entity {
public:
    explicit Player(Position start);

    char symbol() const override;
    void addScore(int delta);
    void collectItem();
    void recordMove();

    int score() const;
    int collectedItems() const;
    int moves() const;

private:
    int score_ = 0;
    int collectedItems_ = 0;
    int moves_ = 0;
};

#endif
