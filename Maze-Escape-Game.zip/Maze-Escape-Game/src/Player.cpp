#include "Player.h"

Player::Player(Position start) : Entity(start) {}

char Player::symbol() const {
    return 'P';
}

void Player::addScore(int delta) {
    score_ += delta;
}

void Player::collectItem() {
    ++collectedItems_;
}

void Player::recordMove() {
    ++moves_;
}

int Player::score() const {
    return score_;
}

int Player::collectedItems() const {
    return collectedItems_;
}

int Player::moves() const {
    return moves_;
}
