#include "Maze.h"

#include <fstream>
#include <stdexcept>

Maze::Maze(const std::string& levelPath) {
    loadLevel(levelPath);
    validateLevel();
}

int Maze::rows() const {
    return static_cast<int>(grid_.size());
}

int Maze::cols() const {
    return grid_.empty() ? 0 : static_cast<int>(grid_.front().size());
}

bool Maze::inBounds(Position pos) const {
    return pos.row >= 0 && pos.row < rows() && pos.col >= 0 && pos.col < cols();
}

bool Maze::isWall(Position pos) const {
    return !inBounds(pos) || grid_[pos.row][pos.col] == '#';
}

bool Maze::isWalkable(Position pos) const {
    return inBounds(pos) && !isWall(pos);
}

bool Maze::isExit(Position pos) const {
    return pos == exitPosition_;
}

bool Maze::hasCollectible(Position pos) const {
    return inBounds(pos) && grid_[pos.row][pos.col] == 'C';
}

bool Maze::collectCollectible(Position pos) {
    if (!hasCollectible(pos)) {
        return false;
    }

    grid_[pos.row][pos.col] = '.';
    return true;
}

const Position& Maze::playerStart() const {
    return playerStart_;
}

const Position& Maze::exitPosition() const {
    return exitPosition_;
}

const std::vector<Position>& Maze::enemyStarts() const {
    return enemyStarts_;
}

int Maze::totalCollectibles() const {
    return totalCollectibles_;
}

std::vector<std::string> Maze::render(
    Position playerPosition,
    const std::vector<Position>& enemyPositions
) const {
    std::vector<std::string> frame = grid_;
    frame[playerPosition.row][playerPosition.col] = 'P';

    for (const Position& enemy : enemyPositions) {
        if (enemy == playerPosition) {
            frame[enemy.row][enemy.col] = 'X';
        } else {
            frame[enemy.row][enemy.col] = 'M';
        }
    }

    return frame;
}

void Maze::loadLevel(const std::string& levelPath) {
    std::ifstream input(levelPath);
    if (!input) {
        throw std::runtime_error("Failed to open level file: " + levelPath);
    }

    std::string line;
    std::size_t expectedWidth = 0;
    bool foundPlayer = false;
    bool foundExit = false;

    while (std::getline(input, line)) {
        if (line.empty()) {
            continue;
        }

        if (expectedWidth == 0) {
            expectedWidth = line.size();
        } else if (line.size() != expectedWidth) {
            throw std::runtime_error("Level rows must all have the same width.");
        }

        int row = static_cast<int>(grid_.size());
        grid_.push_back(line);

        for (int col = 0; col < static_cast<int>(line.size()); ++col) {
            Position pos{row, col};
            char tile = line[col];

            if (tile == 'S') {
                if (foundPlayer) {
                    throw std::runtime_error("Level can only contain one player start.");
                }
                playerStart_ = pos;
                foundPlayer = true;
                grid_[row][col] = '.';
            } else if (tile == 'E') {
                exitPosition_ = pos;
                foundExit = true;
            } else if (tile == 'M') {
                enemyStarts_.push_back(pos);
                grid_[row][col] = '.';
            } else if (tile == 'C') {
                ++totalCollectibles_;
            } else if (tile != '#' && tile != '.') {
                throw std::runtime_error("Unsupported tile in level file.");
            }
        }
    }

    if (!foundPlayer || !foundExit) {
        throw std::runtime_error("Level must contain one player start and one exit.");
    }
}

void Maze::validateLevel() const {
    if (grid_.empty()) {
        throw std::runtime_error("Level cannot be empty.");
    }

    if (totalCollectibles_ == 0) {
        throw std::runtime_error("Level must contain at least one collectible.");
    }

    if (isWall(playerStart_) || isWall(exitPosition_)) {
        throw std::runtime_error("Player start and exit must be on walkable tiles.");
    }
}
