#ifndef ENTITY_H
#define ENTITY_H

#include "Position.h"

class Entity {
public:
    explicit Entity(Position start) : position_(start) {}
    virtual ~Entity() = default;

    const Position& position() const { return position_; }
    void setPosition(Position next) { position_ = next; }
    virtual char symbol() const = 0;

protected:
    Position position_;
};

#endif
