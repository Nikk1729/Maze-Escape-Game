#ifndef GAME_H
#define GAME_H

#include <string>
#include <vector>

#include "Enemy.h"
#include "Maze.h"
#include "Player.h"

struct GameOptions {
    std::string levelPath = "levels/level1.txt";
    std::string replayMoves;
    bool clearScreen = true;
    int turnLimit = 200;
};

class Game {
public:
    explicit Game(const GameOptions& options);
    int run();

private:
    void render() const;
    bool handleInput(char input);
    bool tryMovePlayer(Position delta);
    void moveEnemies();
    bool enemiesCaughtPlayer() const;
    bool victoryReached() const;
    char nextInput();
    void clearTerminal() const;

    Maze maze_;
    Player player_;
    std::vector<Enemy> enemies_;
    GameOptions options_;
    std::string message_;
    std::size_t replayIndex_ = 0;
    bool running_ = true;
    bool playerWon_ = false;
    bool playerLost_ = false;
};

#endif
