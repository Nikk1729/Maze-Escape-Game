#include <iostream>
#include <stdexcept>
#include <string>

#include "Game.h"

namespace {
void printUsage() {
    std::cout
        << "Usage: ./maze_escape [--level PATH] [--replay MOVES] [--no-clear] [--turn-limit N]\n";
}
}

int main(int argc, char* argv[]) {
    GameOptions options;

    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];

        if (arg == "--level" && i + 1 < argc) {
            options.levelPath = argv[++i];
        } else if (arg == "--replay" && i + 1 < argc) {
            options.replayMoves = argv[++i];
        } else if (arg == "--no-clear") {
            options.clearScreen = false;
        } else if (arg == "--turn-limit" && i + 1 < argc) {
            options.turnLimit = std::stoi(argv[++i]);
        } else if (arg == "--help") {
            printUsage();
            return 0;
        } else {
            printUsage();
            return 1;
        }
    }

    try {
        Game game(options);
        return game.run();
    } catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << "\n";
        return 1;
    }
}
