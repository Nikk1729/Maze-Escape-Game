#ifndef MAZE_H
#define MAZE_H

#include <string>
#include <vector>

#include "Position.h"

class Maze {
public:
    explicit Maze(const std::string& levelPath);

    int rows() const;
    int cols() const;
    bool inBounds(Position pos) const;
    bool isWall(Position pos) const;
    bool isWalkable(Position pos) const;
    bool isExit(Position pos) const;
    bool hasCollectible(Position pos) const;
    bool collectCollectible(Position pos);

    const Position& playerStart() const;
    const Position& exitPosition() const;
    const std::vector<Position>& enemyStarts() const;
    int totalCollectibles() const;

    std::vector<std::string> render(
        Position playerPosition,
        const std::vector<Position>& enemyPositions
    ) const;

private:
    void loadLevel(const std::string& levelPath);
    void validateLevel() const;

    std::vector<std::string> grid_;
    Position playerStart_{};
    Position exitPosition_{};
    std::vector<Position> enemyStarts_;
    int totalCollectibles_ = 0;
};

#endif
