#include "Enemy.h"

Enemy::Enemy(Position start) : Entity(start) {}

char Enemy::symbol() const {
    return 'M';
}
